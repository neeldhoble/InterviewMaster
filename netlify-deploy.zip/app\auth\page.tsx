import { AuthScreen } from "@/features/auth/components/AuthScreen";

export default function AuthPage() {
    return <AuthScreen />
}