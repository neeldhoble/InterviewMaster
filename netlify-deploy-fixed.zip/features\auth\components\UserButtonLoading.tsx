export const UserButtonLoading = () => {
    return (
        <span className="size-10 rounded-md bg-foreground/50 animate-pulse transition-colors"/>
    )
}