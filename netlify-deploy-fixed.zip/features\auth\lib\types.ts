// TODO: Add all the types that will be used across your apps

// Use for Authentication
export type AuthFlow = "signIn" | "signUp";